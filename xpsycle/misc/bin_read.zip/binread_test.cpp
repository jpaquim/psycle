/****************************************************************************
*   Copyright (C) 2006 by Stefan  Nattkemper                              *
*   natti@linux                                                           *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/

#include "binread.h"
#include "preset.h"
#include <iostream>
#include <fstream>
#include <string>


int main( int argc, char *argv[] )
{   
  std::string filename;
  bool full = false;

  if ( argc < 2 ) {
    std::cout << "filepath missing"  << std::endl;
    std::cout << "usage : bintest <filename> {optional:-v}" << std::endl;
    std::cout << "-v full knob values" << std::endl;
    return EXIT_SUCCESS;
  } else {
    filename = argv[1];
    if ( ( argc == 3) && std::string("-v")==argv[2] ) full = true;

  }

  std::string::size_type pos = filename.find('.')  ;
  if ( pos == std::string::npos ) {
    filename  = filename + '.' + "prs";
  }

  std::ifstream prsIn( filename.c_str() );
  if ( !prsIn.is_open() ) {
    std::cout << "couldnt open file"  << std::endl;
    return EXIT_SUCCESS;
  }

  std::cout << "reading preset: " << filename << std::endl;

  psycle::host::BinRead binIn( prsIn );

  psycle::host::BinRead::BinPlatform platform = binIn.platform();

  switch ( platform ) {
        case psycle::host::BinRead::byte4LE : 
          std::cout << "platform is little endian 4 byte" << std::endl;
          break;
        case psycle::host::BinRead::byte4BE : 
          std::cout << "platform is big endian 4 byte" << std::endl;
          break;
        case psycle::host::BinRead::byte8LE : 
          std::cout << "platform is little endian 8 byte" << std::endl;
          break;
        case psycle::host::BinRead::byte8BE : 
          std::cout << "platform is big endian 8 byte" << std::endl;
          break;
  }


  int numpresets = binIn.readInt4LE();
  int filenumpars = binIn.readInt4LE();

  if (numpresets >= 0) {
    // old file format .. do not support so far ..
  } else {
    // new file format
    if ( filenumpars == 1 ) {
      int filepresetsize;
      // new preset format version 1
      // new preset format version 1

      int numpresets = binIn.readInt4LE();
      filenumpars = binIn.readInt4LE();
      filepresetsize = binIn.readInt4LE();

      while ( !prsIn.eof() ) {
        psycle::host::Preset newPreset(filenumpars, filepresetsize);
        if (newPreset.read( binIn )) {
          std::cout << "prs name:" << newPreset.name() << ", ";
          std::cout << "knob number" << newPreset.parameter().size() << std::endl;
          for ( std::vector<int>::const_iterator it = newPreset.parameter().begin(); it < newPreset.parameter().end(); it++  ) {            
            std::cout << "param value" << *it << "; ";
            if ( !full) break;
          }
          std::cout << "end" << std::endl;
        }
        else 
          break;
      }
    }
  }
  return EXIT_SUCCESS;
}
