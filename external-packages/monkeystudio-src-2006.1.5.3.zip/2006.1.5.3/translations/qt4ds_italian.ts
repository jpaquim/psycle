<!DOCTYPE TS><TS>
<context>
    <name>MDIClass</name>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OS...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One or more file(s) are requesting to save them,
under witch OS do you want to add them ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save the header file
[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save the source file
[%1]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MDIText</name>
    <message>
        <source>Can&apos;t save the file [%1]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCompletion</name>
    <message>
        <source>Show Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Others</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMakeProject</name>
    <message>
        <source>UI Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project %1 has been modified, save it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Critical...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Question...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initializing Application...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language changed to locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently no Web browser is selected.
Please use the settings dialog to specify one!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently no PDF viewer is selected.
Please use the settings dialog to specify one!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant is unable to start the PDF Viewer

%1

Please make sure that the executable exists and is located at
the specified location.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSearchReplaceDialog</name>
    <message>
        <source>Search - Replace Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whole word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Match case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search from start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Not Found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replacing done, %1 occurences replace</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextEditor</name>
    <message>
        <source>Save File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This file has been modified,
[%1],
save it ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the line number you want to go to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIAbout</name>
    <message>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Informations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Greetings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIAddExistingFiles</name>
    <message>
        <source>Choose files to add to the project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In project...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIHeaderInformations</name>
    <message>
        <source>Header Informations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commentary :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>License :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QPL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dd/MM/yyyy @ hh:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date - Time :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not show again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open header informations templates.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIMain</name>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently Opened Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently Opened Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rebuild</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Widgets Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close the current tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save all open files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As &amp;Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the current tab as a template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure application options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show widgets box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show projects box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show messages box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New F&amp;orm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new form to the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Files...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new file(s) to the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Existing Files...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add existing file(s) to the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure the current project options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build all projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rebuild the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rebuild all projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean all projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lupdate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute lupdate on the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lrelease</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute lrelease on the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Qt Assistant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About the application...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit tools menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save all projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close all projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Templates...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new template to the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the project source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ToDo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the project ToDo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the project Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build And Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build the current project and execute it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go To Line...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected file from project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove and &amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove The selected file from project and delete it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not yet implemented</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This project file doesn&apos;t exists.
ie: &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close project?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a Qt Project to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processus terminated, Exit Code : %1, Exit Status : %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executing %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter command line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt4DS Monkey Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Qt Assistant with Qt4DS Monkey manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UINewFiles</name>
    <message>
        <source>New Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can write a not existing path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Gui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Dll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Static Lib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt PlugIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can omit the extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the exact basename of your file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PlugIn Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collection PlugIn Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a path for your project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a path for your file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create the file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create the template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the window manager for the file(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the file to include,
it will be used to create the default application widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must this class herits from something ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the file to herits from,
you can directly enter a Qt Class :( ie: QWidget or qwidget.h )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the plugin file header to use :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIOptions</name>
    <message>
        <source>Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload last opened project when program starts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload documents when opening project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create backup file when saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic reload of externally modified files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statement Completion Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto list functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Word Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable color syntax highlighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print line numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Qt Warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Header Informations Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Showing Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smart Indent Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent open brace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent closing brace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Indent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt 4 Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Templates Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Documentation Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save files before building</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Number Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preprocessor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White Spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the mingw path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the Qt 4 path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the templates path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the translations path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the documentation path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Web Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the executable for the PDF Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the executable for the web browser</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIProjectSettings</name>
    <message>
        <source>Project Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;1 Project Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a Qt application/library and requires the Qt header files/library. The proper include and library paths for the Qt library will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Qt Modules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt 3 compatibility classes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt3Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for database integration using SQL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtSql</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OpenGL support classes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtOpenGL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for network programming.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for displaying the contents of SVG files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtSvg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graphical user interface components.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtGui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Core non-GUI classes used by other modules.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtCore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for handling XML.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtXml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>app</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vcapp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vclib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>subdirs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configures qmake to run uic3 on the content of FORMS3 if defined, else FORMS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>uic3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ensures that the list of libraries stored in the LIBS variable is not reduced to a list of unique values before it is used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no_lflags_merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exception support is enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RTTI support is enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rtti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STL support is enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Template :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Language :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Con&amp;figuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler should only emit severe warnings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>warn_off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler should emit more warnings than normally, ignored if &quot;warn_off&quot; is specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>warn_on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile with optimization enabled, ignored if &quot;debug&quot; is specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile with debug options enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OS Specific</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When using the vcapp template this will put all the source files into the source group and the header files into the header group regardless of what directory they reside in. Turning this option off will group the files within the source/header group depending on the directory they reside. This is turned on by default.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>flat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Builds a PowerPC binary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ppc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Builds an i386 compatible binary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x86</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puts the library into a library bundle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lib_bundle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puts the executable into a bundle (this is the default).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>app_bundle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Incl. - Libs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a multi-threaded application or library. The proper defines and compiler flags will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a X11 application or library. The proper include paths and libraries will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a Win32 window application (app only). The proper include paths,compiler flags and libraries will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a Win32 console application (app only). The proper include paths, compiler flags and libraries will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a shared object/DLL.The proper include paths, compiler flags and libraries will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a static library (lib only). The proper compiler flags will automatically be added to the project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>staticlib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The target is a plugin (lib only). This enables dll as well.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Support for online help.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtAssistant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for extending Qt Designer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtDesigner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classes for handling Qt Designer forms in applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtUiTools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool classes for unit testing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QtTest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extension for accessing ActiveX controls.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QAxContainer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extension for writing ActiveX servers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QAxServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2 WS Specific Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LIBS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DEFINES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INCLUDEPATH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DEPENDPATH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VPATH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RESOURCES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DEF_FILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC_FILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RES_FILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Version :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>win32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Target :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Destination :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;System :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;3 Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the destination path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type your library name or path
(like: -lLIB or -L&quot;PATH&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type your define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose your new %1 directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Resources (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Def Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rc Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Res Files (%1);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose your new %1 file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify a library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify a define</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UISubclassWizard</name>
    <message>
        <source>SubClass Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Window Manager :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent Class :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>win32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create the files.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIToolsEdit</name>
    <message>
        <source>Tools Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Tools Editor&lt;/b&gt; give you the possibility to use variables&lt;br&gt;&lt;br&gt;&lt;b&gt;%n&lt;/b&gt; : Current project name&lt;br&gt;&lt;b&gt;%p&lt;/b&gt; : Current project path&lt;br&gt;&lt;b&gt;%f&lt;/b&gt; : Current project file path&lt;br&gt;&lt;b&gt;%d&lt;/b&gt; : Selected file path ( In Project Box )&lt;br&gt;&lt;b&gt;%g&lt;/b&gt; : Selected file file path ( In Project Box )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose an icon for this tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
