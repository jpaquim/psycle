//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by foo_sample.rc
//
#define IDD_PLAYBACK_STATE              101
#define IDD_DSP                         102
#define IDD_MYPREFERENCES               148
#define IDC_BOGO1                       1001
#define IDC_BOGO2                       1002
#define IDC_PATTERN                     1002
#define IDC_STATE                       1003
#define IDC_PLAY                        1004
#define IDC_PAUSE                       1005
#define IDC_STOP                        1006
#define IDC_PREV                        1007
#define IDC_NEXT                        1008
#define IDC_RAND                        1009
#define IDC_CONTEXTMENU                 1010
#define IDC_SLIDER1                     1012
#define IDC_SLIDER                      1012
#define IDC_SLIDER_LABEL                1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
